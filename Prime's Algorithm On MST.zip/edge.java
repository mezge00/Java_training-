
// Create an edge with its attributes,
// Those are the weight or the distance between two nodes
// and the other is destination vertex or node
public class edge{
		int weight;  // The weight between two nodes
		int destination;  // The node to be joined with the edge or destinationNOde
		// Creating a constructor to invoke the above variables
		edge(int destination,int weight ){
			this.destination=destination;
			this.weight=weight;
		}
	}
	