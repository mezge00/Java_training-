import primesAlgorithm.Graph;

public class Ckecker {

	public static void main(String[] args) {
		
		mstGraph.addEdge(1, 2, 5);

}
