
public class Nodee {
	 int vertex;
	    int key;
	

}
