
public class Node {
	Character data;
	Node next;
	Node tail;
	Node(Character data){
		this.data=data;
		
	}

}
