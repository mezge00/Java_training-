
public class divideConquerIntMult {

	public static void main(String[] args) {
		
//System.out.println(args.length);
	}
	public void multiply(int x,int y) {
		
	}

}
