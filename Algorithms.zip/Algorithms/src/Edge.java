
public class Edge {
	
	    // Source node
	    int u;
	    // Destination node
	    int v;
	    // Edge weight
	    int weight;
	    public Edge(int u, int v, int weight)
	    {
	        this.u = u;
	        this.v = v;
	        this.weight = weight;
	    }
	}


