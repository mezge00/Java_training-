
public class Test {

	public static void main(String[] args) {
		
	    myframe Water=new myframe();
		//new verfiyLogin("karen@gmail.com","199800","CustomersList.txt");
		
	   
		//System.out.println(fib(100));

	}
public static int fib(int n) {
	if(n==0|n==1)
		return 1;
	else
		return fib(n-2)+fib(n-1);
}
}
