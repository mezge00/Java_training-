
public class Calculate {
	Double cost;
	public Double calculate(Double Volume) {
		cost=0.3*Volume;
		return cost;
		
	}

}
