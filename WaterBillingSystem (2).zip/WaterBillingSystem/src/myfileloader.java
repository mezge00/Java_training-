import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class myfileloader {
	//myframe loginpr=new myframe();
	
	String email,password,phone,lName,fName;
	public myfileloader(String str) {
		
		Scanner lineScanner=new Scanner(str);
		lineScanner.useDelimiter(",");
		//while(lineScanner.hasNext()) {
			//if(lineScanner.equals(loginpr.emailText)){
				email=lineScanner.next();
				password=lineScanner.next();
				phone=lineScanner.next();
				lName=lineScanner.next();
				fName=lineScanner.next();
		 
			try {
				Scanner sc=new Scanner(new File("CustomersList.txt"));
				myfileloader assign=null;
				//while(sc.hasNext()) {
				//	String str=sc.next();
					 assign=new myfileloader(str);
					
				//}
				//name.setText(assign.fName+" "+assign.lName);
				sc.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
		lineScanner.close();
		
	}
	
}
