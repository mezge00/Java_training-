import java.io.*;
public class CustomersList {
	public static void main() {
		
	}
	FileWriter writer;
	FileReader reader;
	CustomersList(){
	try {
		 writer=new FileWriter("CustomersList.txt");
		 reader=new FileReader("CustomersList.txt");
		reader.read();
		
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	}

}
