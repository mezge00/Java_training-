
public class NullInputException extends Exception {
	NullInputException(String str){
		super(str);
	}

}
