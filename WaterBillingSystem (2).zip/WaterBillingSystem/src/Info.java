import javax.swing.*;


public class Info {
	
	JPanel panel2;
	Info(){
		panel2=new JPanel();
		panel2.setSize(600, 600);
		panel2.setLayout(null);
		
		
	}

}
