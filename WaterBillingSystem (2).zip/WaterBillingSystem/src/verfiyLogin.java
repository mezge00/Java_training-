import java.io.File;
import java.util.Scanner;

public class verfiyLogin {
	String userName;
	String password;
	String filePath;
	//String phone,lName,fName;
	//myframe jfar=new myframe();
	
	boolean find=false;
	static Scanner x;
	public  verfiyLogin(String userName,String password,String filePath) {
		
		this.userName=userName;
		this.password=password;
		this.filePath=filePath;
		
		String tempuserName="";
		String temppassword="";
		String tempPhone="";
		
		
		try {
			x=new Scanner(new File(filePath));
			x.useDelimiter("[,\n]");
			while(x.hasNext()&&!find) {
				tempuserName=x.next();
				temppassword=x.next();
				tempPhone=x.next();
				
				
				if(tempuserName.trim().equals(userName.trim())&&temppassword.trim().equals(password.trim()))
					find=true;	
			}
			
			x.close();
			System.out.println(find);
			
		}catch(Exception e) {
			System.out.println(e.getStackTrace());
		}
		
	}

}
