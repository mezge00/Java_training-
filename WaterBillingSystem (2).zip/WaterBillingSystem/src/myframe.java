/*
 * WATER BILLING SYSTEM- OOP PROJECT-
 * SECTION 3
 * @
 * GROUP MEMBERS - - - - - - - - ID
 * 1. MEZGEBU BIRHAN            UGR/17382/11
 * 2. SOLOMON SHEWAREGA         UGR/19636/12
 * 3. WALELIGN BIRHANU          UGR/19619/12
 * 4. HANON ALEMAYEHU           UGR/19680/12
 * 5. EYOAB TARIKU              UGR/19600/12
 * 6. SISAY ASFAW               UGR/20003/12
*/
import java.awt.*;

import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.*;

public class myframe extends JFrame implements ActionListener{
	JPanel panel,panel2,panel3,panel4,panel5;
	JButton SignUp,SignUp2,Next,Next2,Login,Back,Submit;
	JTextField fNameText,lNameText,phoneText,emailText,newPassword,name;
	JTextField mytext,amount,mytext21,totalValue;
	JTextField accountNumber,ExpDate,phoneNumber,securityCode;
  
	JPasswordField mytext2;
	JComboBox<String> chooseBank;
	JComboBox<String> chooseway;
	
	
	
	
	//Info a=new Info();
	
	myframe(){
		
		panel=new JPanel();
		
		panel.setSize(600, 700);
		panel.setBackground(Color.white);
		panel.setLayout(null);
		
		panel2=new JPanel();
		panel2.setSize(600, 600);
		panel2.setBackground(new Color(30,45,200));
		panel2.setLayout(null);
		
		panel3=new JPanel();
		panel3.setSize(600, 700);
		panel3.setBackground(new Color(120,15,150));
		panel3.setLayout(null);
		
		panel4=new JPanel();
		panel4.setSize(600, 700);
		panel4.setBackground(new Color(100,167,167));
		panel4.setLayout(null);
		
		panel5=new JPanel();
		panel5.setSize(600, 700);
		panel5.setBackground(new Color(0,125,0));
		panel5.setLayout(null);
		
		
		
		
		JLabel label=new JLabel("User Name");
		label.setBounds(30, 20, 100, 80);
		
		JLabel header=new JLabel("Water Billing System ");
		header.setFont(new Font("Times New Roman",Font.BOLD,18));
		header.setBounds(200, -21, 200, 80);
		header.setEnabled(true);
		
		
		
		JLabel label2=new JLabel();
		label2.setText("Passoword");
		label2.setForeground(Color.BLACK);
		label2.setBounds(30, 70, 100, 80);
		
		JLabel Full_Name=new JLabel();
	    Full_Name.setText("Email");
		Full_Name.setBounds(50, 20, 100, 80);
		
		JLabel Status=new JLabel();
		Status.setText("Status");
		Status.setBounds(30, 120, 100, 80);
		
		JLabel amounts=new JLabel("PLease Enter the amount in liters");
		amounts.setBounds(60, 60, 400, 80);
		amount=new JTextField("20");
		amount.setBounds(200,110,49,25);
		amount.setFont(new Font("TimesNewRoman",Font.BOLD,14));
		totalValue=new JTextField();
		totalValue.setBounds(100,100,49,20);
		
		//-----------------for summary page--------
		JLabel accountNo=new JLabel("Account number");
		accountNo.setBounds(30, 60, 100, 80);
		
		accountNumber=new JTextField();
		accountNumber.setBounds(150, 100, 200, 20);
		JLabel expdate=new JLabel("Expiry Date");
		expdate.setBounds(30, 140, 100, 80);
		ExpDate=new JTextField();
		ExpDate.setBounds(150, 175, 200, 20);
		JLabel secCode=new JLabel("Security code");
		secCode.setBounds(30, 220, 100, 80);
		securityCode=new JTextField();
		securityCode.setBounds(150, 250, 200, 20);
		
		
		
		//------------------for SignUp page--------------
		
		JLabel fName=new JLabel("First Name");
		fName.setBounds(30, 20, 100, 80);
		fNameText=new JTextField("Enter Name your firts name");
		fNameText.setBounds(150, 60, 200, 20);
		fNameText.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		JLabel lName=new JLabel("Last Name");
		lName.setBounds(30, 100, 100, 80);
		lNameText=new JTextField("Enter your lastname ");
		lNameText.setBounds(150, 135, 200, 20);
		lNameText.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		
		JLabel email=new JLabel("Email");
		email.setBounds(30, 200, 100, 80);
		emailText=new JTextField("09");
		emailText.setBounds(150, 290, 200, 20);
		emailText.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		
		
		JLabel phone=new JLabel("Phone Number");
		phone.setBounds(30, 250, 100, 80);
		phoneText=new JTextField("");
		phoneText.setBounds(150, 235, 200, 20);
		phoneText.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		JLabel passworLabel=new JLabel("New Password");
		passworLabel.setBounds(30, 320, 120, 80);
		newPassword=new JPasswordField();
		newPassword.setBounds(150, 350, 200, 20);
		
		
		
		
	
		
		
	
		Login=new JButton("Login");
		Login.setBounds(200, 150, 100, 30);
		Login.addActionListener(this);
		SignUp=new JButton("Sign Up");
		SignUp.setBounds(350, 150, 100, 30);
		
		Back=new JButton("Back");
		Back.setBounds(10, 400, 100, 30);
		Back.addActionListener(this);
		Back.setForeground(new Color(94,190,190));
		Back.setBackground(Color.PINK);
		
		
		SignUp2=new JButton("Sign Up");
		SignUp2.setBounds(350, 400, 100, 30);
		SignUp2.setForeground(new Color(200,200,2));
		SignUp2.setOpaque(true);
		SignUp2.setBackground(new Color(48,149,30));
		SignUp2.setBorderPainted(true);
		
		SignUp.addActionListener(this);
		SignUp2.addActionListener(this);
		
		Submit=new JButton("Submit");
		Submit.setBounds(150, 300, 100, 50);
		Submit.addActionListener(this);
		Submit.setForeground(new Color(94,190,190));
		Submit.setBackground(Color.PINK);
		
		
		
		//for panel2
		Next=new JButton("Next");
		Next.setBounds(300, 200, 100, 30);
		Next.addActionListener(this);
		
		// for panel 3
		Next2=new JButton("Pay");
		Next2.addActionListener(this);
		Next2.setBounds(200, 150, 100, 30);
		JLabel summary=new JLabel("Total Payment page");
		summary.setFont(new Font("Times New Roman",Font.BOLD,18));
		summary.setBounds(200, -21, 200, 80);
		summary.setEnabled(true);
		JLabel price=new JLabel("Price");
		price.setBounds(40,100,50,30);
		
		//----------for panel 5_
		String[] Banks= {"Commercial Bank","Buna Bank","Abyssinya Bank","Dashen"};
		chooseBank=new JComboBox<String>(Banks);
		chooseBank.setBounds(40, 10, 200, 20);
		chooseBank.addActionListener(this);
		
		String[]paymentMethod= {"Credit card","CVE"};
		
		chooseway=new JComboBox<String>(paymentMethod);
		chooseway.setBounds(30,50,200,20);
		//chooseway.setAlignmentY(LEFT_ALIGNMENT);
		//------------
		JLabel label3=new JLabel("Forgot Passoword");
		label3.setBounds(200, 430, 150, 80);
		
		mytext=new JTextField("takelederese@gmail.com");
		mytext.setBounds(150, 50, 200, 20);
		mytext.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		mytext2=new JPasswordField("199800");
		mytext2.setBounds(150, 100, 200, 20);
		mytext2.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		mytext2.getHighlighter();
		
		//----------------------text for page 2---------------
		name=new JTextField("");
		name.setBounds(150, 50, 200, 20);
		name.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		JTextField stat=new JTextField("Not paid");
		stat.setBounds(150, 150, 200, 20);
		stat.setFont(new Font("TIMES NEW ROMAN",Font.BOLD, 14));
		
		
		panel.add(mytext2);
		panel.add(mytext);
		panel.add(label2);
		panel.add(label3);
		
		panel2.add(Full_Name);
		panel2.add(Status);
		panel2.add(amounts);
		panel2.add(name);
		panel2.add(stat);
		panel2.add(amount);
		
		panel4.add(lName);
		panel4.add(fName);
		panel4.add(email);
		panel4.add(phone);
		panel4.add(passworLabel);
		
		
		panel4.add(SignUp2);
		panel4.add(newPassword);
		panel4.add(fNameText);
		panel4.add(lNameText);
		panel4.add(phoneText);
		panel4.add(emailText);
		panel4.add(Back);
		
		panel5.add(chooseBank);
		panel5.add(secCode);
		panel5.add(securityCode);
		panel5.add(accountNo);
		panel5.add(accountNumber);
		panel5.add(expdate);
		panel5.add(ExpDate);
		panel5.add(Submit);
		
		panel.add(header);
		panel.add(SignUp);
		panel.add(Login);
		panel.add(label);
		panel2.add(Next);
		panel3.add(Next2);
		panel3.add(summary);
		panel3.add(totalValue);
		panel3.add(price);
		
		
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500, 500);
		this.add(panel);
		
		this.setVisible(true);
		//this.pack();
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==Login) {
			@SuppressWarnings("deprecation")
			verfiyLogin a=new verfiyLogin(mytext.getText(),mytext2.getText(), "CustomersList.txt");
			if(a.find==true) {
				panel.setVisible(false);
				
				this.add(panel2);
				panel2.setVisible(true);
				name.setText(mytext.getText());
				//name.setText(lineScanner.next(pattern));
				//while(lineScanner.hasNext()) {
					//if
						//String phoneTextt=lineScanner.next();
						//String lNameTextt=lineScanner.next();
						//String fNameTextt=lineScanner.next();
				 
					//name.setText(fNameTextt+lNameTextt);
						
						//}
			}
			else 
				JOptionPane.showMessageDialog(this, "You are not Rigistered please sign up!");
			
			}
		//-----------
		if(e.getSource()==Next) {
			panel2.setVisible(false);
			panel3.setVisible(true);
			this.add(panel3);
			
			}
		if(e.getSource()==SignUp2) {
		    String Fname=fNameText.getText();
			String Lname=lNameText.getText();
			String Email=emailText.getText();
			String phoneNumber=phoneText.getText();
			String pasword=newPassword.getText();
			Double cost = null;
			
		    try {
		    	FileOutputStream file=new FileOutputStream("CustomersList.txt",true);
		    	PrintWriter print=new PrintWriter(file);
		    	print.println(phoneNumber+","+pasword+","+Email+","+Lname+","+Fname+",");
		    	JOptionPane.showMessageDialog(this, "You are registered please login");
		    	print.close();
				panel.setVisible(true);
				panel4.setVisible(false);
				
			}catch(FileNotFoundException a) {
				System.out.println("File not found");
			}
			
			
		}
		if(e.getSource()==SignUp) {
			panel.setVisible(false);
			this.add(panel4);
			panel4.setVisible(true);
		}
		if(e.getSource()==Back) {
			panel4.setVisible(false);
			panel.setVisible(true);
			
		}
		if(e.getSource()==Next) {
		try {
			if( Double.parseDouble(amount.getText())<0)
				throw new NullInputException("You entered wrong value");
            
			Calculate Calculator=new Calculate();
			Double price=Calculator.calculate((Double.parseDouble(amount.getText())));
			

			panel2.setVisible(false);
			panel3.setVisible(true);
			totalValue.setText((Double.toString(price)));
			
		
				
				
			}catch(NullInputException t) {
				JOptionPane.showMessageDialog(this, "Sorry you entered!");
			}
		
		}
		if(e.getSource()==Next2) {
			panel3.setVisible(false);
			this.add(panel5);
			panel5.setVisible(true);
			
		}
		if(e.getSource()==chooseBank) {
			panel5.add(chooseway);
			
		}
		if(e.getSource()==Submit) {
			if(accountNumber.getText()!=null&&ExpDate.getText()!=null
					&& securityCode!=null) {
				JOptionPane.showMessageDialog(null, "Great you have paid for this month");
               this.dispose();
			}//else
				//JOptionPane.showMessageDialog(null, "Please enter the required fileds");
		}
		
			
			
		}
	
	
	}




