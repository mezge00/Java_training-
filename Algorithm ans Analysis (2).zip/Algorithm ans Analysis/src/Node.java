
public class Node {
	char data;
	public Node(char N) {
		this.data=N;
		
		
	}

}
