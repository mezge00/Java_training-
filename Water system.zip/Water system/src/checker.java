
public class checker {
	public static void main(String [] args) {
		new myframe();
	}
}
