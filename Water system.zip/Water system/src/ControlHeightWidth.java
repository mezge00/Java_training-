import java.util.Scanner;
import javax.swing.*;
public class ControlHeightWidth {
	static void checkHW(Double height,Double Width) throws InvalidHeightWidth{
		if(height<0|Width<0) {
			throw new InvalidHeightWidth("You entered You entered a negative number");
			
		}else {
			Double periemeter=2*(height+Width);
			System.out.println("The permeter of the rectangle is "+periemeter);
		}
	}

	public static void main(String [] args) {
		Scanner in=new Scanner(System.in);
		try {
			
			System.out.println("Please enter the width and height of the rectangle");
			Double h=in.nextDouble();
			Double w=in.nextDouble();
			checkHW(h,w);
			
		}catch(InvalidHeightWidth inv) {
			System.out.println("You entered wrong input: "+inv);
			
		}
	}
	
}
