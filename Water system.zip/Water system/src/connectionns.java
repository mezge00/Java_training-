import java.sql.*;
public class connectionns {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
			System.out.println("Hi ");
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Hi ");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sys","birhan","Mt@1998002");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from employee;");
			//System.out.println("Esay database connected ");
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.getSQLState();
		}
		

	}

}
