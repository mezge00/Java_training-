
public class InvalidHeightWidth extends Exception{
	InvalidHeightWidth(String str){
		super(str);
		
	}

}
