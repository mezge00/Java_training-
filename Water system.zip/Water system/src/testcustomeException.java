import java.util.Scanner;

public class testcustomeException {

	static void validate(int age ) throws InvalidageException{
		if(age<18) {
			throw new InvalidageException("Age not valid ");
		}else {
			System.out.println("Welcome to vote");
		}
		
	}
	public static void main(String[] args) {
		try {
			Scanner in=new Scanner(System.in);
			System.out.println("Please enter the number that you want to check");

			int n=in.nextInt();
			validate(n);
		}catch(InvalidageException ex) {
			System.out.println("Caught the Exception");
			System.out.println("Exception Occured "+ex);
			
			
		}
		// TODO Auto-generated method stub

	}

}
