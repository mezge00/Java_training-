
public class InvalidageException extends Exception{
	public InvalidageException(String str) {
		super(str);
		
	}
}
