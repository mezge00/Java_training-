import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
public class myframe extends JFrame implements ActionListener{
	JButton save;
	JButton clear;
	JLabel itemName,Description,Quality,Price;
	JTextField Name,describ,qual,cost;
	JPanel panel;
	JTable table;
	JScrollPane sp;
	String data []= {"coffee","2019 model","Brand","20"};
	myframe(){
		
		//String clumn[]= {"itemName","Description","Quality","Price"};
		//table=new JTable();
		save=new JButton("Save");
		clear =new JButton("Clear");
		save.setBounds(30, 100, 130, 30);
		save.addActionListener(this);
		clear.setBounds(150, 100, 130, 30);
		clear.addActionListener(this);
		
		Name=new JTextField(" ");
		Name.setBounds(30,40,100,15);
		describ=new JTextField(" ");
		describ.setBounds(30,70,100,15);
		
		qual=new JTextField("");
		qual.setBounds(30,60,30,15);
		cost=new JTextField(" ");
		cost.setBounds(30,70,30,15);
		
		panel=new JPanel();
		panel.setSize(500, 400);
		panel.setBackground(Color.green);
		panel.setLayout(null);
		sp=new JScrollPane(table);
		sp.setBounds(10, 1, 300, 100);
		//panel.add(sp);
		panel.add(save);
		panel.add(clear);
		panel.add(Name);
		panel.add(describ);
		//panel.add(Price);
		
		
		
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600,500);
		this.setLayout(null);
		
		this.add(panel);
		this.setVisible(true);
		//this.pack();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==save)
			//panel.add(table);
			Name.setText(data[1]);
			//panel.add(sp);
		String ho=" ";
		if(e.getSource()==clear)
			Name.setText("");
			//table.setShowHorizontalLines(isBackgroundSet());
		
	}

}
