public class forcheck{
void eat() {
	System.out.println("animal is eating...");
	}
}
class Dog extends forcheck{
void eat(){
	System.out.println("dog is eating...");
	}
}
