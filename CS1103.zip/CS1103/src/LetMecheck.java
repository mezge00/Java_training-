
public class LetMecheck extends practice {

	public static void main(String[] args) {
		practice myCheck=new practice();
		myCheck.ID=2837;
		System.out.println(ID);
		int a=3;
		int b=2;
		int x=(b>a)?a:b;
		System.out.println(x);

	}

}
