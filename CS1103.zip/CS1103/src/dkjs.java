
class test{
public static void main(String args[])
{
	WeeklyEmp WEmp1=new WeeklyEmp("abebe",12,120,5);
   WEmp1.setSal();
  partimeEmp PEmp= new partimeEmp("Bekele",13,30,120); 
  PEmp.setsal();
}
}

