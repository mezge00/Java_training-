import java.util.Scanner;

public class ExTest {
	
	public static void main(String [] ags) {
		int num1=0;
		int num2=1;
		int sum=0;
		int add=0;
		
		while(num1!=1 || num2!=1) {
			add=num1+num2+add;
			num1=(int)(Math.random()*6)+1;
			num2=(int)(Math.random()*6)+1;
			
			sum++;
		}
		//System.out.println("We found the two numbers to be equal after "+sum+" trials");
		System.out.println("We founf the snake eye after "+sum+" trials");
		System.out.println(num1+" "+num2);
		System.out.println(add);

	
		
	}

}
