public class Animal{
	static {int y=6;
	System.out.println(y);
	}
	public static void main(String [] args) {
		
		for(String i:args) {

			System.out.print(i);
			System.out.print(" ");
		}
		
		
		
	}
	
}