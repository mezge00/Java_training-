
public class myInterface {

	public static void main(String[] args) {
		int [] A= {5,3,4,6,2};
		
		int N;
		for(int i=0; i<A.length;i++) {
			N=A[i];
			for(int j=1;j<A.length;j++) {
				if(A[j]<N)
					A[j]=N;
			}
			
		A[i]=N;
		
		}
		for(int k:A) {
			System.out.println(k);}
	}

}
