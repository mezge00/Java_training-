
public class BabyDog1 extends Dog{
	public static void main(String [] args){ 
	forcheck a=new BabyDog1();
	a.eat();
}
}
