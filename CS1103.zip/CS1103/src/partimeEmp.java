public class partimeEmp extends Employee{

    private int rate,whr;

    public partimeEmp (String n, int i,int r,int h) {
        super(n,i);//calls Employee constructor
        rate = r;
         whr=h;
    }

    public void setsal() {
        salary=rate*whr;
    }

}