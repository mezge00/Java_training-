import java.util.Scanner;

public class Eculidean {

	public static void main(String[] args) {
	
		System.out.println(gcd(11,25));
		// TODO Auto-generated method stub

	}
	public static int gcd(int a,int b ){
		if(a==0)
			return b;
		else {
			return gcd(a%b,a);
			
		}
			
			
		
		
	}

}
