
public class practice {
	 static String name="mer";
	 static int ID=777;
	 String Campus;
	 public void set(String name,int ID) {
		 this.name=name;
		 this.ID=ID;
		 
		 
	 }
	 
	 public String getName() {
		 return name;
	 }
	 public int getID() {
		 return ID;
	 }
	public  void freshCafe() {
		System.out.println("Those who are fresh students can eat on the caf 2");
		
		
	}
	public  void dormitory() {
		System.out.println("The dormitory for each student is found on the council");
		
	}

}
