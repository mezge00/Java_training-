
public class Letme extends practice{
	public static void main(String [] args) {
		practice my=new practice();
		my.name="Mezgebu";
		my.ID=29293;
		my.dormitory();
		my.set("Boy", 3445);
		System.out.println(my.getID());
		System.out.println(my.getName());

		
	}

}
