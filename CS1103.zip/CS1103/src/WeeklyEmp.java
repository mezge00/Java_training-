public class WeeklyEmp extends Employee{

    private int wrate,nwk;

  public WeeklyEmp(String n, int i,int r,int nw) {
        super(n,i);//calls Employee constructor
        wrate = r;
		  nwk=nw;
         
    }

    public void setSal() {
        salary=wrate*nwk;
    }

}