class Test {
int a,b;
public Test(){
send();
}
public Test(int z){
this(4,z);}
Test(int a, int x) {
this.a = a;
b=x;}
Test mtest(Test t) {
 t.a+=3;
 t.b+=6;
Test temp = new Test(a,b);
return temp; }
void send(){
mtest(this);}}
class TestObjasretuntype {
public static void main(String args[]) {
Test ob1 = new Test();
Test ob2= new Test(5,4);
Test ob3=new Test(3);
//ob1.send();
ob1= ob1.mtest(ob1);
ob2=ob2.mtest(ob2);
ob3=ob3.mtest(ob3);
System.out.println("After first call value ob1.b: " + ob1.b);
System.out.println("After first call value ob2.b: " + ob2.b);
System.out.println("After first call value ob3.b: " + ob3.b);
ob1=ob1.mtest(ob1);
ob2 = ob2.mtest(ob2);
ob3=ob3.mtest(ob3);
System.out.println("ob1.a , ob2.a and ob3.a. after second Call:" + ob1.a+" "+ob2.a+" "+ob3.a);
}}