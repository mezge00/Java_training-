public class series {
	public static void main(String [] args) {
		try {
		System.out.println(fact(6));
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public static int fib(int x) {
		if(x==0||x==1)
			return 1;
		else
			return fib(x-1)+fib(x-2);
	}
	
	public static int fact(int n) {
		if(n==0||n==1)
			return 1;
		else
			return n*fact(n-1);
	}

}
