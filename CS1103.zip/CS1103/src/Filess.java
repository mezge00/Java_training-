import java.io.*;
public class Filess {

	public static void main(String[] args) {
		//File file=new File("/home/mezgebu/eclipse-workspace/CS1103/src/testdata.txt");
		FileWriter Writer;
		FileReader read;
		try {
			read=new FileReader("pom.txt");
			int data=read.read();
			
			Writer = new FileWriter("CustomersList.txt");/*
			Writer.write("I love someone but it is hard to intergrate it!!\n"
					+ "But I still have a nice dreat no to be \n beaten by any intruptions ");
			Writer.append("\nMezee Says!!");
			Writer.close();*/
			while(data!=-1) {
				System.out.print((char)data);
				data=read.read();
			}
			read.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		/*if(file.exists()) {
			System.out.println("the file is here");
			System.out.println(file.isFile());}
		else
			System.out.println("Nop");*/

	}

}
