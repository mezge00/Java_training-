import java.util.Scanner;

public class Changes {

	public static void main(String[] args) {
		double amount=3;
		double T_amount=0;
		String peny=new Scanner(System.in).nextLine();
		String diem=new Scanner(System.in).nextLine();
		for(int i=1;i<5;i++) {
			if(peny=="penies") {
				amount=0.4*amount;
			}
			else if(diem=="di") {
				amount=0.5*amount;
				T_amount=T_amount+amount;
				}
		}
		

	}

}
