public class rectangle {
double width;
double length;
 rectangle() {
 width=4;
 length =6;
 calcArea(width,length);
 }
 rectangle(double width,double length)
 {
 this.width=width;
 this.length= length;
 width=length=7;
 calcArea(width,length);
 calcArea(this.width,this.length);
 this.width=length=2;
 calcArea(width,length);
 calcArea(this.width,this.length);
 }
void calcArea(double width,double length){
double ar= width*length;
 System.out.println("AREA="+ ar);
}
 }
class RectDemo {
public static void main(String args[]){
rectangle rect1 = new rectangle();
rect1.calcArea(9,4);
rectangle rect2 = new rectangle(8,6);
}
}