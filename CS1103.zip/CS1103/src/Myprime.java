import java.util.Scanner;
import java.awt.geom.*;;
public class Myprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		//Scanner in=new Scanner(System.in);
		//System.out.println("Enter the maximum number that you want: ");
		
		//int N=in.nextInt();
		int []N= {6,34,12,7,5,9,13,17};
		
		
		for(int i=0;i<N.length; i++) {
			int counter=0;
			for( int j=1; j<=N[i];j++) {
				if(N[i]%j==0)
					counter++;	
			}
			if(counter==2)
				System.out.println(N[i]+" is a prime number ");
			else
				System.out.println(N[i]+" is composite number: ");
			
				
		}
		
		
		
	}

}
