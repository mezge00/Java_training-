public class Employee{

    private String name;
		float salary;
     int id;

    public Employee(String n,int id) {
        name = n;
		this.id=id;
    }
  public String getName(){ return name; }

    public int getid() { return id; }

}